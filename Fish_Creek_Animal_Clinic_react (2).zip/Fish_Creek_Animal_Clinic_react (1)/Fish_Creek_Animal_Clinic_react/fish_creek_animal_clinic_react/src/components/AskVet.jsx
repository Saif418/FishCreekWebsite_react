import React from "react"
import { Link } from 'react-dom'



function AskVet() {

    return (
        <main>
            <p>
                Contact us if you have a question that you would like answered here.
            </p>
            <dl>
                <dt>Question: Our dog, Sparky, likes to eat whatever the kids are snacking on. Is it OK for the dog to eat chocolate?</dt>
                <dd>� Chocolate is toxic to dogs. Please do not feed your dog chocolate. Try playing a game with your children � when you feed them people treats, they can feed Sparky dog treats.</dd>
            </dl>
        </main>
    );

}
export default AskVet;

